import json
import urllib.parse
import boto3
import pandas as pd
from io import BytesIO


s3 = boto3.client('s3')

FILENAME_TO_BUCKET = {
    'movies.parquet': 'cdd-movies',
    'ratings.parquet': 'cdd-ratings',
    'tags.parquet': 'cdd-tags'
}

def copy_files():
    response = s3.list_objects_v2(Bucket='cdd-rawdata')
    
    for obj in response['Contents']:
        key = obj['Key']
        if key == 'ratings.parquet':
            continue
        response = s3.copy_object(Bucket=FILENAME_TO_BUCKET[key], CopySource={'Bucket': 'cdd-rawdata', 'Key': key}, Key=key)

def load_file_to_process(file_to_process):
    response = s3.get_object(Bucket='cdd-rawdata', Key=file_to_process)
    df = pd.read_parquet(BytesIO(response['Body'].read()))
    return df

def lambda_handler(event, context):
    copy_files()
    print('success')
